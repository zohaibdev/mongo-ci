<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['host'] = 'cluster0.tgqsr.gcp.mongodb.net';
$config['port'] = 27017;
$config['username'] = 'mayasmsuser';
$config['password'] = 'U63EIEmWov9Ccjt8';
$config['collecion'] = 'MayabytesSMS';
$config['authenticate'] = FALSE;

